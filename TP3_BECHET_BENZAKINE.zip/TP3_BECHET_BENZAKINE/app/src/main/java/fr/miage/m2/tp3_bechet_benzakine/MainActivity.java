package fr.miage.m2.tp3_bechet_benzakine;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Intent i ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Random random = new Random();
        int res = random.nextInt(3) + 1;
        i = new Intent(this, WinLose.class);
        i.putExtra("resultat", res);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.porte1:
                i.putExtra("porte", 1);
                startActivity(i);
                break;
            case R.id.porte2:
                i.putExtra("porte", 2);
                startActivity(i);
                break;
            case R.id.porte3:
                i.putExtra("porte", 3);
                startActivity(i);
                break;
            case R.id.about:
                break;

        }

    }
}