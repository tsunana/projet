package fr.miage.m2.tp3_bechet_benzakine;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class WinLose extends AppCompatActivity implements View.OnClickListener {

    private Intent i;
    private TextView textView;
    private int res ;
    private int porte ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_winlose);
        i = getIntent();
        res = i.getIntExtra("resultat",0) ;
        porte = i.getIntExtra("porte",0);
        textView = findViewById(R.id.fin);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.oui:
                if (porte == res) {
                    textView.setText("Gagné !");
                } else {
                    textView.setText("Perdu !");
                }
                break;
            case R.id.non:
                if (porte != res) {
                    textView.setText("Gagné !");
                } else {
                    textView.setText("Perdu !");
                }
                break;
        }
    }
}